vertical_tile_number = 11 # 44
tile_size = 64

screen_width = 1280
screen_height = vertical_tile_number * tile_size
